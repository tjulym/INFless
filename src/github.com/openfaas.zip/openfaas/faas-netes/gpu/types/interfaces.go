package types

type ResourceDisplay interface {
	ToString()
}

