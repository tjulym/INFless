//@file: estimator.go
//@author: Yanan Yang
//@date: 2020/11/9
//@note:
package controller

import (
	"fmt"
	gTypes "github.com/openfaas/faas-netes/gpu/types"
	"io/ioutil"
	"log"
	"os"
	"strconv"
	"strings"
)

var resnet50 map[string]float64
var catdog  map[string]float64
var lstm_maxlass2365 map[string]float64
var textcnn69 map[string]float64
var ssd map[string]float64
var mobilenet map[string]float64






func InitProfiler() {
	resnet50 = make(map[string]float64)
	catdog = make(map[string]float64)
	lstm_maxlass2365 = make(map[string]float64)
	textcnn69 = make(map[string]float64)
	ssd = make(map[string]float64)
	mobilenet = make(map[string]float64)

	initModel(resnet50,"./yaml/profiler/resnet-50-profile-results.txt")
	initModel(catdog,"./yaml/profiler/catdog-profile-results.txt")
	initModel(lstm_maxlass2365,"./yaml/profiler/lstm-maxclass-2365-profile-results.txt")
	initModel(textcnn69,"./yaml/profiler/textcnn-69-profile-results.txt")
        initModel(ssd,"./yaml/profiler/ssd-profile-results.txt")
        initModel(mobilenet,"./yaml/profiler/mobilenet-profile-results.txt")
}

func initModel(model map[string]float64, filePath string) {
	file, err := os.Open(filePath)
	if err != nil {
		log.Println(err)
	}
	defer file.Close()
	content, err := ioutil.ReadAll(file)
	lines := strings.Split(strings.TrimSpace(string(content)), "\n")
	for _, value := range lines {
		params := strings.Split(value, " ")
		latency, err := strconv.ParseFloat(params[4], 64)
		if err == nil {
			model[params[1]+"_"+params[2]+"_"+params[3]] = latency
		}
	}
	if len(model) > 0 {
		log.Printf("estimator: read model %s profiling data successfully, profiling data size=%d\n",filePath, len(model))
	}

}

func inferResourceConfigsWithBatch(funcName string, latencySLO float64, batchSize int32, residualReq int32)(instanceConfig []*gTypes.FuncPodConfig, err error){
	var availInstConfigs []*gTypes.FuncPodConfig
	/**
	 * verify latencySLO is reasonable
	 */
	 /*
	minExecTimeWithGpu := int32(execTimeModel(funcName,1, 2,100))
	minExecTimeOnlyCpu := int32(execTimeModelOnlyCPU(funcName,1, 2))
	if latencySLO < minExecTimeOnlyCpu && latencySLO < minExecTimeWithGpu {
		//log.Printf("estimator: latencySLO %d is too low to be met with minExecTimeOnlyCPU=%d and minExecTimeWithGpu=%d(cpuThread=%d)\n",latencySLO, minExecTimeOnlyCpu, minExecTimeWithGpu, batchSize)
		err = fmt.Errorf("estimator: latencySLO %d is too low to be met with minExecTimeOnlyCPU=%d and minExecTimeWithGpu=%d(batchSize=%d)\n",latencySLO, minExecTimeOnlyCpu, minExecTimeWithGpu, batchSize)
		return nil, err
	}*/

	 sloMeet := false
	/**
	 * deal with batch size=1
	 */
	timeForExec := latencySLO/2
	initCpuThreads := batchSize
	if batchSize == 1 {
		timeForExec = latencySLO //no need to queue batch
		initCpuThreads = 2 // at least allocate 2 CPU threads
	}
	//- supportBatchGroup[i]/reqArrivalRate
	//supportCPUthreadsGroup := [...]int32{16,8,4,2,1}
	reqPerSecondMax := int32(0)
	reqPerSecondMin := int32(0)
	batchTimeOut := int32(0)
	for cpuThreads := initCpuThreads; cpuThreads > 0; cpuThreads = cpuThreads-2 { //cpu threads decreases with 2
		expectTime := generalExecTimeModel(funcName, batchSize, cpuThreads, 0)
		if gTypes.LessEqual(expectTime, timeForExec) {
			sloMeet = true
			reqPerSecondMax = int32(1000/expectTime*float64(batchSize)) //no device idle time - queuing time equals execution time
			if batchSize == 1 {
				reqPerSecondMin = 1
				batchTimeOut = 0
			} else {
				reqPerSecondMin = int32(1000/(latencySLO-expectTime)*float64(batchSize))
				batchTimeOut = int32(latencySLO-expectTime)*1000
				if batchTimeOut < 0 {
					batchTimeOut = 0
				}
			}

			if residualReq >= reqPerSecondMin {
				availInstConfigs = append(availInstConfigs, &gTypes.FuncPodConfig {
					BatchSize:      batchSize,
					CpuThreads:     cpuThreads,
					GpuCorePercent: 0,
					GpuMemoryRate: -1,
					ExecutionTime:  int32(expectTime),
					BatchTimeOut: batchTimeOut,
					ReqPerSecondMax: reqPerSecondMax,
					ReqPerSecondMin: reqPerSecondMin,
				})
				//log.Printf("estimator: function=%s, batch=%d, cpuThread=%d, gpuPercent=%d, batchTimeOut=%d, value=%d\n", funcName,batchSize,cpuThreads,int32(0),batchTimeOut,int32(expectTime))
			}
		}
		for gpuCorePercent := 50; gpuCorePercent > 0; gpuCorePercent = gpuCorePercent - 10 { //gpu cores decreases with 10%
			expectTime = generalExecTimeModel(funcName, batchSize, cpuThreads, int32(gpuCorePercent))
			if gTypes.LessEqual(expectTime, timeForExec) {
				sloMeet = true
				reqPerSecondMax = int32(1000/expectTime*float64(batchSize)) //no device idle time - queuing time equals execution time
				if batchSize == 1 {
					reqPerSecondMin = 1
					batchTimeOut = 0
				} else {
					reqPerSecondMin = int32(1000/(latencySLO-expectTime)*float64(batchSize))
					batchTimeOut = int32(latencySLO-expectTime)*1000
					if batchTimeOut < 0 {
						batchTimeOut = 0
					}
				}

				if residualReq >= reqPerSecondMin {
					availInstConfigs = append(availInstConfigs, &gTypes.FuncPodConfig {
						BatchSize:      batchSize,
						CpuThreads:     cpuThreads,
						GpuCorePercent: int32(gpuCorePercent),
						GpuMemoryRate: -1,
						ExecutionTime:  int32(expectTime),
						BatchTimeOut: batchTimeOut,
						ReqPerSecondMax: reqPerSecondMax,
						ReqPerSecondMin: reqPerSecondMin,
					})
					//log.Printf("estimator: function=%s, batch=%d, cpuThread=%d, gpuPercent=%d, batchTimeOut=%d, value=%d\n", funcName,batchSize,cpuThreads,int32(gpuCorePercent),batchTimeOut,int32(expectTime))
				}
			}
		}
	}
	if len(availInstConfigs) > 0 {
		return availInstConfigs,nil
	} else {
		if sloMeet == true {
			err = fmt.Errorf("estimator: residualReq %d is too low to be met with (batchsize=%d)\n",residualReq, batchSize)
		} else {
			err = fmt.Errorf("estimator: latencySLO %f is too low to be met with (batchsize=%d)\n",latencySLO, batchSize)
		}

		return nil, err
	}
}

//func execTimeModel(funcName string, batchSize int32, cpuThread int32, gpuCorePercent int32) float64{
//	if funcName == "resnet50" {
//		b := float64(batchSize)
//		t := float64(cpuThread)
//		g := float64(gpuCorePercent) / 100
//		return float64(1423)*b/(t+40.09)*math.Pow(g,-0.3105)+17.92
//	}
//	log.Printf("estimator: could find exection time model for function %s", funcName)
//	return 99999
//}
//func execTimeModelOnlyCPU(funcName string, batchSize int32, cpuThread int32) float64{
//	if funcName == "resnet50" {
//		b := float64(batchSize)
//		t := float64(cpuThread)
//		return 34.76*b/(math.Pow(t,0.341)-0.9926)+69.87+150
//	}
//	log.Printf("estimator: could find exection time model(only CPU) for function %s", funcName)
//	return 99999
//
//}



func generalExecTimeModel(funcName string, batchSize int32, cpuThread int32, gpuCorePercent int32) float64{
	key := strconv.Itoa(int(cpuThread)) + "_" + strconv.Itoa(int(gpuCorePercent)) + "_" + strconv.Itoa(int(batchSize))
	value := float64(0)
	ok := false
	if funcName == "resnet-50" {
		value, ok = resnet50[key]
	} else if funcName == "catdog" {
		value, ok = catdog[key]
	} else if funcName == "lstm-maxclass-2365" {
		value, ok = lstm_maxlass2365[key]
	} else if funcName == "textcnn-69" {
		value, ok = textcnn69[key]
	} else if funcName == "ssd" {
		value, ok = ssd[key]
	} else if funcName == "mobilenet" {
		value, ok = mobilenet[key]
	}
	if ok {
		//log.Printf("estimator: function=%s, batch=%d, cpuThread=%d, gpuPercent=%d, value=%f", funcName,batchSize,cpuThread,gpuCorePercent,value)
		return value
	} else {
		//log.Printf("estimator: could not find exection time model for function=%s, batch=%d, cpuThread=%d, gpuPercent=%d", funcName,batchSize,cpuThread,gpuCorePercent)
		return 99999
	}
}



