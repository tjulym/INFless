kubectl apply -f yaml/inuse
kubectl get all -n openfaasdev|grep gate
