## 64-bit ARM YAML files

Follow steps for the `yaml` files for `x86_64`: [YAML](../yaml/)

When creating new functions from templates, make sure you use the ones ending in `-arm64`.

If there are specific templates or languages you would like to see for 64-bit ARM, please reach [out on Slack](https://docs.openfaas.com/community) or raise an issue on the [templates repo](https://github.com/openfaas/templates/).
