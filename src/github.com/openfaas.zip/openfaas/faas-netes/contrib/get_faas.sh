#!/bin/bash

curl -sL https://cli.openfaas.com | sudo sh