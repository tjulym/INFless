## OpenFaaS - Serverless Functions Made Simple for Docker & Kubernetes 

![https://blog.alexellis.io/content/images/2017/08/faas_side.png](https://blog.alexellis.io/content/images/2017/08/faas_side.png)

Please see the [official documentation site](https://docs.openfaas.com) or our [more detailed set of guides on GitHub](https://github.com/openfaas/faas/tree/master/guide).
