Building:

```
docker build -t functions/prometheus:2.2.0-armhf .
```
