# Alertmanager for ARM64

## Building:

```bash
make ci-arm64-build
```

## Pushing:

```bash
make ci-arm64-push
```
