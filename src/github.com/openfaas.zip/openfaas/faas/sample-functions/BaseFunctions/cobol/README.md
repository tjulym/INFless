GNUCobol
=========

Any binary can become a FaaS process, even Cobol through GNUCobol.

Here's an example of deploying this base function to FaaS which reads from stdin (called SYSIN in Cobol) and prints it to the screen.

![https://pbs.twimg.com/media/C_AMvtcXcAAbnGk.jpg:large](https://pbs.twimg.com/media/C_AMvtcXcAAbnGk.jpg:large)
