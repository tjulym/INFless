#!/bin/sh

echo "Building functions/base:golang-1.7.5-alpine"
docker build -t functions/base:golang-1.7.5-alpine .
