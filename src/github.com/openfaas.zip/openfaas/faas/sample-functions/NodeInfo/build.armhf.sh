#!/bin/sh

docker build -f Dockerfile.armhf -t functions/nodeinfo:latest-armhf .
